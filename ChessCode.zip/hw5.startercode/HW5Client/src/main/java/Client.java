import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.function.Consumer;

public class Client extends Thread {
	Socket socketClient;
	ObjectOutputStream out;
	ObjectInputStream in;
	private Consumer<Serializable> callback;
	Client(Consumer<Serializable> call) {
		callback = call;
	}

	public void run() {
		try {
			socketClient = new Socket("127.0.0.1", 5555);
			out = new ObjectOutputStream(socketClient.getOutputStream());
			out.flush();
			in = new ObjectInputStream(socketClient.getInputStream());
			socketClient.setTcpNoDelay(true);
		} catch (Exception e) {
			callback.accept("Could not connect to server");
			return;
		}
		while (true) {
			try {
				Message message = (Message) in.readObject();
				callback.accept(message);
			} catch (Exception e) {
				callback.accept("Disconnected from server");
				break;
			}
		}
	}

	public void send(Message message) {
		try {
			out.writeObject(message);
			out.flush();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}